<template>
  <main class="p-4 max-w-3xl mx-auto">
    <h1 class="text-3xl font-bold mb-4">ברוכים הבאים לכושר קרבי אשקלון</h1>
    <p class="mb-6">הכנה פיזית ומנטלית לצה״ל, עם מאמנים בעלי ניסיון קרבי אמיתי.</p>

    <section class="mb-6">
      <h2 class="text-xl font-semibold">קצת עלינו</h2>
      <p>אנחנו מציעים אימונים אישיים וקבוצתיים, סדנאות שטח, וליווי עד הגיוס.</p>
    </section>

    <section class="mb-6">
      <h2 class="text-xl font-semibold">סרטון מוטיבציה</h2>
      <video controls class="w-full mt-2 rounded shadow">
        <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
        הדפדפן שלך לא תומך בוידאו.
      </video>
    </section>

    <section class="mb-6">
      <h2 class="text-xl font-semibold">צור קשר</h2>
      <form class="space-y-4 mt-2">
        <input type="text" placeholder="שם" class="w-full border p-2 rounded" />
        <input type="email" placeholder="אימייל" class="w-full border p-2 rounded" />
        <textarea placeholder="הודעה" class="w-full border p-2 rounded"></textarea>
        <button class="bg-blue-600 text-white px-4 py-2 rounded">שלח</button>
      </form>
    </section>
  </main>
</template>